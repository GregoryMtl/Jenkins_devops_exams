# Dépôts et configuration
* Webhook   : http://3.248.59.150:8080/github-webhook
* Repo      : https://github.com/GregoryMtl/Jenkins_devops_exams
* DockerHub :

# Notes
* Agent : quel node execute la pipeline (any/none/label)
* Environment : variables d'environnement
* Triggers : actions automatisées
    * pollSCM : vérifications de code source avec syntaxe type cron
    * upstream : si job précédent réalisé avec succès
* Post : commandes exécutées à la fin du pipeline
* Stages : segments d'exécution (ex: dev, qa, staging, deploy:prod, approval, build...)
* Steps : séquence d'étapes, exemple, build, test, deploy
* Script : ....
* Input : demande une entrée utilisateur (message,id,ok, submitter...)
* Parallel : permet d'exécuter parallèlement plusieurs étapes
* Parameters : permet de définir uneliste de paramètres
* Tools:  définit les versions des JDK à utiliser, ex `tools { maven 'apache-maven-3.0.6' }`
* When : exécuté lorsque la condition est remplie, ex `when { branch 'master' } steps { // ... }`

# Initialisation
```
sudo chmod 644 /etc/rancher/k3s/k3s.yaml
kubectl apply -f namespaces.yaml


mkdir ~/.kube
sudo kubectl config view --raw > ~/.kube/config
cat ~/.kube/config

```

Le fichier `config` est copié sur la machine personnelle.

Sur jenkins, des nouveaux identifiants sont créés :
* Un secret file `config`, contenant la configuration Kubernetes sauvegardée juste avant
* Un secret pass `DOCKER_HUB_PASS` content mon mot de passe Docker Hub

# Création du chart Helm



